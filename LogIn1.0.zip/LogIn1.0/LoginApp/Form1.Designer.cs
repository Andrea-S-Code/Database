﻿
namespace LoginApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.UserNametxt = new System.Windows.Forms.Label();
            this.Passwordtxt = new System.Windows.Forms.Label();
            this.UserNameIn = new System.Windows.Forms.TextBox();
            this.PasswordIn = new System.Windows.Forms.TextBox();
            this.LogInBut = new System.Windows.Forms.Button();
            this.LogInBox = new System.Windows.Forms.GroupBox();
            this.LogInBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // UserNametxt
            // 
            this.UserNametxt.AutoSize = true;
            this.UserNametxt.Location = new System.Drawing.Point(28, 38);
            this.UserNametxt.Name = "UserNametxt";
            this.UserNametxt.Size = new System.Drawing.Size(62, 15);
            this.UserNametxt.TabIndex = 0;
            this.UserNametxt.Text = "UserName";
            // 
            // Passwordtxt
            // 
            this.Passwordtxt.AutoSize = true;
            this.Passwordtxt.Location = new System.Drawing.Point(28, 82);
            this.Passwordtxt.Name = "Passwordtxt";
            this.Passwordtxt.Size = new System.Drawing.Size(57, 15);
            this.Passwordtxt.TabIndex = 1;
            this.Passwordtxt.Text = "Password";
            this.Passwordtxt.Click += new System.EventHandler(this.label1_Click);
            // 
            // UserNameIn
            // 
            this.UserNameIn.Location = new System.Drawing.Point(96, 35);
            this.UserNameIn.Name = "UserNameIn";
            this.UserNameIn.Size = new System.Drawing.Size(100, 23);
            this.UserNameIn.TabIndex = 2;
            // 
            // PasswordIn
            // 
            this.PasswordIn.Location = new System.Drawing.Point(96, 79);
            this.PasswordIn.Name = "PasswordIn";
            this.PasswordIn.Size = new System.Drawing.Size(100, 23);
            this.PasswordIn.TabIndex = 3;
            // 
            // LogInBut
            // 
            this.LogInBut.AccessibleName = "";
            this.LogInBut.Location = new System.Drawing.Point(115, 119);
            this.LogInBut.Name = "LogInBut";
            this.LogInBut.Size = new System.Drawing.Size(71, 27);
            this.LogInBut.TabIndex = 4;
            this.LogInBut.Text = "LogIn";
            this.LogInBut.UseVisualStyleBackColor = true;
            this.LogInBut.Click += new System.EventHandler(this.LogInBut_Click);
            // 
            // LogInBox
            // 
            this.LogInBox.Controls.Add(this.LogInBut);
            this.LogInBox.Controls.Add(this.PasswordIn);
            this.LogInBox.Controls.Add(this.UserNameIn);
            this.LogInBox.Controls.Add(this.Passwordtxt);
            this.LogInBox.Controls.Add(this.UserNametxt);
            this.LogInBox.Location = new System.Drawing.Point(36, 29);
            this.LogInBox.Name = "LogInBox";
            this.LogInBox.Size = new System.Drawing.Size(262, 210);
            this.LogInBox.TabIndex = 5;
            this.LogInBox.TabStop = false;
            this.LogInBox.Text = "LogInBox";
            this.LogInBox.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // Form1
            // 
            this.AccessibleName = "LogInBut";
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(805, 446);
            this.Controls.Add(this.LogInBox);
            this.Name = "Form1";
            this.Text = "LogIn";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.LogInBox.ResumeLayout(false);
            this.LogInBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label UserNametxt;
        private System.Windows.Forms.Label Passwordtxt;
        private System.Windows.Forms.TextBox UserNameIn;
        private System.Windows.Forms.TextBox PasswordIn;
        private System.Windows.Forms.Button LogInBut;
        private System.Windows.Forms.GroupBox LogInBox;
    }
}

