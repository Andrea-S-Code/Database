﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace LoginApp
{
    public partial class LogOutBut : Form
    {
        public LogOutBut()
        {
            InitializeComponent();
        }

        private void Log_Click(object sender, EventArgs e)
        {

        }
    }
}
