﻿namespace LoginApp
{
    internal class SqlDataAdapter
    {
    }
}